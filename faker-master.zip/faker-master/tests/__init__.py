try:
    string_types = (basestring,)
except NameError:  # pragma: no cover
    string_types = (str,)
